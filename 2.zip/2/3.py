import random

def isPrime(a):
    for i in range(2,int(a/2) +1):
        if(a%i==0):
            return False

    return True


L=[]
for i in range(100):
    L.append(random.randint(100,900))

count_prime=0
count_even=0
count_odd=0

for i in L:
    
    if(i%2==0):
        count_even=count_even+1
    else:
        count_odd=count_odd+1

    if(isPrime(i)):
        count_prime=count_prime+1

print('Number of even:  ',count_even)
print('Number of odd:   ',count_odd)
print('Number of prime: ',count_prime)
    
