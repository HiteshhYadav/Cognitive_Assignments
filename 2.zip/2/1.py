L=[10,20,30,40,50,60,70,80]
L.append(200)
L.append(300)
print(L)

L.remove(10)
L.remove(30)
print(L)

L.sort()
print(L)

L.sort(reverse=True)
print(L)
