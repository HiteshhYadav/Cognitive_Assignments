T=(45,89.5,76,45.4,89,92,58,45)
print('Max',max(T))
print('Index:',T.index(max(T)))

print('\n')
print('Min',min(T))
print('Count:',T.count(min(T)))
print('\n')

L=list(reversed(T))
print('Reversed tuple as List:',L)


num=eval(input('Enter a number to check:'))

if(num in T):
    print('Present at:',T.index(num))
else:
    print(num,' is not in tuple')
