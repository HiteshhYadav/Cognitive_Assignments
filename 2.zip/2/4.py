A={34,56,78,90}
B={78,45,90,23}
C=set()

C=A|B

print('Union: ',C)


D=set()
D=A&B

print('Intersection: ',D)


E=set()
E=A.symmetric_difference(B)

print('A-B UNION B-A: ',E)



if(A.issubset(B) or B.issuperset(A)):
    print('A is subset of B')
else:
    print('A is not a subset of B')



num=int(input('Enter a number to remove from A: '))
        
if(num in A):
    A.discard(num)
else:
    print(num,' is not present in A')
print('A: ',A)
