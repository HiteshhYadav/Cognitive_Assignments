a=9+8
b="Semester "+"IV"
c="Semester "+str(4)
print(a)
print(b)
print(c)
