import math
from datetime import datetime

print(math.cos(0))
print(math.cos(math.pi))
print(math.fabs(-3))


a=int(input('Enter a number:'))
b=math.pow(a,1/2)
print('Square root of ',a,' is:',b)






print('\n\n')
now=datetime.now()
date=now.strftime("%d/%m/%Y")
time=now.strftime("%H:%M:%S")
print("Current Date:",date)
print("Current time:",time)



print('\n\n')
import os
print('List of files:',os.listdir())
