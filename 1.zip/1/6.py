a=input('Enter the string:')

count=0
for i in a:
    if i in "aeiou":
        count=count+1

print('Number of vowels:',count)

b=a[::-1]
print('Reveresed:',b)

string=input('Enter a string to check:')
revStr=string[::-1]
if(revStr==string):
    print('Entered string is palindrome')
else:
    print('Entered string is not palindrome')
