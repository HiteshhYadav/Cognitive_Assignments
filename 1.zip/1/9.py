import random
print('Five random numbers')
for i in range(5):
    print(random.randint(1,100))




print('\n\n')
num=random.randint(1,100)
flag=True
for i in range(2,int(num/2) +1):
    if(num%i==0):
        flag=False
        break
if(flag==True):
    print(num,' is prime')
else:
    print(num,' is not prime')




print('\n\n')
choice=int(input('Enter 1 to roll a die:'))
if(choice==1):
    print('You got ',random.randint(1,6))



print('\n\n')
l=[1,2,3,4,5]
random.shuffle(l)
print('Shuffled: ',l)



print('\n\n')
num=random.choice(l)
print('Number randomly chosen: ',num)



print('\n\n')
list_of_chars="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()"
length=int(input('Enter the length of password:'))
password=""
for i in range(length):
    password=password+random.choice(list_of_chars)
print("Your password is: ",password)




print('\n\n')
cards=["Diamonds","Spades","Hearts","Clubs"]
ranks=[2,3,4,5,6,7,8,9,0,"Jack","Queen","King","Ace"]
card=random.choice(cards)
rank=random.choice(ranks)
print(rank," of ",card)
