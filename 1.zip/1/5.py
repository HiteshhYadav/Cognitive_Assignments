L=[1,2,3,4,5]
print('Max:',max(L))
print('Min:',min(L))

dict1={1:'One',2:'Two',3:'Three'}
a=eval(input('Enter the key:'))
print('Value:',dict1[a])


list1=[25,34,22,66,32,102,91]
list1.sort()
print('Sorted list in ascending order :',list1)
list1.sort(reverse=True)
print('Sorted list in descending order:',list1)


dict2={4:'Four',5:'Five',6:'Six'}
dict1.update(dict2)
print(dict1)
