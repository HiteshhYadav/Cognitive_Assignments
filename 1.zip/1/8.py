a=int(input('Enter a number:'))
b=int(input('Enter a number:'))

try:
    result=a/b
    print('Result:',result)
except:
    print('Zero divison error')



try:
    num=int(input('Enter a number:'))
    print('Valid')
except:
    print('You didnt enter a number')



try:
    num=int(input('Enter a number to divide 15:'))
    res=15/num
except:
    print('Zero divison error')
else:
    print('Result:',res)
finally:
    print('Completed')
