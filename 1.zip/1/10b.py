import sys
length=len(sys.argv[1])
print("Length of ",sys.argv[1]," is: ",length)

"""
Output:
py 10b.py "hello"
Length of  hello  is:  5
"""
