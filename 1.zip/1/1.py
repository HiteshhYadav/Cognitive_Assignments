print('Cse')
