import sys
n=len(sys.argv)
print("Total parameters in argv:",n)

sum_=0

#Summing all the values in argv of sys

for i in range(1,n):
    sum_=sum_+int(sys.argv[i])

print('The sum is:',sum_)

"""
Output:
py 10.py 1 2 3
4
The sum is: 6

"""


