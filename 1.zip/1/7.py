file=open("file.txt","w")

file.write("Cognitive Computing\n")
print("Data written")
file.close()

file=open("file.txt","r")
print(file.read())
file.close()




file=open("file.txt","a")
file.write("Semester IV\n")
file.close()

file=open("file.txt","r")
print(file.read())
file.close()





file=open("file.txt","r")
print('Number of lines:',len(file.readlines()))
file.close()

