print('Using for loop:')
for i in range(1,11,1):
    print(i)

print('\n\n')
print('Using while loop:')
num=0
while(num<11):
    print(num)
    num=num+1

print('\n\n')
sum1=0
for i in range(1,101,1):
    sum1=sum1+i
print('Sum:',sum1)
