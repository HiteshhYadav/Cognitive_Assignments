a=int(input('Enter a number:'))

if(a==0):
    print('Zero')
elif(a>0):
    print('Positive number')
elif(a<0):
    print('Negative number')

if(a%2==0):
    print('Number is even')
else:
    print('Number is odd')
